package br.com.caelum.ed;

public class ListaAlunos {
    private Aluno[] alunos;
    private int totalDeAlunos;

    public ListaAlunos() {
        this.alunos = new Aluno[100];
        this.totalDeAlunos = 0;
    }

    public void adiciona(Aluno aluno) {
        if (totalDeAlunos == alunos.length) {
            Aluno[] novaLista = new Aluno[alunos.length * 2];
            for (int i = 0; i < totalDeAlunos; i++) {
                novaLista[i] = alunos[i];
            }
            alunos = novaLista;
        }
        alunos[totalDeAlunos] = aluno;
        totalDeAlunos++;
    }

    public void adiciona(int posicao, Aluno aluno) {
        if (posicao < 0 || posicao > totalDeAlunos) {
            throw new IllegalArgumentException("Posição inválida");
        }

        for (int i = totalDeAlunos - 1; i >= posicao; i--) {
            alunos[i + 1] = alunos[i];
        }

        alunos[posicao] = aluno;
        totalDeAlunos++;
    }

    public Aluno pega(int posicao) {
        if (!posicaoOcupada(posicao)) {
            throw new IllegalArgumentException("Posição inválida");
        }
        return alunos[posicao];
    }

    public void remove(int posicao) {
        if (!posicaoOcupada(posicao)) {
            throw new IllegalArgumentException("Posição inválida");
        }

        for (int i = posicao; i < totalDeAlunos - 1; i++) {
            alunos[i] = alunos[i + 1];
        }

        totalDeAlunos--;
        alunos[totalDeAlunos] = null;
    }

    public boolean contem(Aluno aluno) {
        for (int i = 0; i < totalDeAlunos; i++) {
            if (alunos[i].equals(aluno)) {
                return true;
            }
        }
        return false;
    }

    public int tamanho() {
        return totalDeAlunos;
    }

    private boolean posicaoOcupada(int posicao) {
        return posicao >= 0 && posicao < totalDeAlunos;
    }
}

