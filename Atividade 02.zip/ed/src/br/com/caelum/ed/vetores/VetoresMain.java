import br.com.caelum.ed.Aluno;
import br.com.caelum.ed.vetores.Vetor;
import java.util.ArrayList;
import java.util.Vector;

public class VetoresMain {
    public static void main(String[] args) {
        // 1) 
        Vetor<Aluno> vetorCaelum = new Vetor<>();
        for (int i = 0; i < 1000; i++) {
            Aluno aluno = new Aluno();
            vetorCaelum.adiciona(aluno);
        }

        // 2) 
        System.out.println("Tamanho do vetor da classe Vetor (antes): " + vetorCaelum.tamanho());

        // 3) 
        Vector<Aluno> vectorJava = new Vector<>(vetorCaelum.tamanho());
        for (int i = 0; i < vetorCaelum.tamanho(); i++) {
            vectorJava.add(vetorCaelum.pega(i));
        }


        System.out.println("Tamanho do vetor da classe Vector (antes): " + vectorJava.size());
        for (int i = 0; i < 1000; i++) {
            Aluno aluno = new Aluno();
            vectorJava.add(aluno);
        }
        System.out.println("Tamanho do vetor da classe Vector (depois): " + vectorJava.size());

        // 4) 
        ArrayList<Aluno> arrayListJava = new ArrayList<>(vectorJava.size());
        arrayListJava.addAll(vectorJava);

        System.out.println("Tamanho do vetor da classe ArrayList (antes): " + arrayListJava.size());
        for (int i = 0; i < 1000; i++) {
            Aluno aluno = new Aluno();
            arrayListJava.add(aluno);
        }
        System.out.println("Tamanho do vetor da classe ArrayList (depois): " + arrayListJava.size());
    }
}

