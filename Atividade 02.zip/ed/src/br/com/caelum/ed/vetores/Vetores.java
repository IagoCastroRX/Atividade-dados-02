package br.com.caelum.ed.vetores;

public class Vetores<T> {
  
    private Object[] elementos = new Object[100000];
    private int totalDeElementos = 0;

    private void garantaEspaco() {
        if (this.totalDeElementos == this.elementos.length) {
            Object[] novaArray = new Object[this.elementos.length * 2];
            for (int i = 0; i < this.elementos.length; i++) {
                novaArray[i] = this.elementos[i];
            }
            this.elementos = novaArray;
        }
    }

    public void adiciona(T elemento) {
        this.garantaEspaco();
        this.elementos[this.totalDeElementos] = elemento;
        this.totalDeElementos++;
    }

    public void adiciona(int posicao, T elemento) {
        this.garantaEspaco();
        if (posicao < 0 || posicao > totalDeElementos) {
            throw new IllegalArgumentException("Posição inválida");
        }

        for (int i = totalDeElementos - 1; i >= posicao; i--) {
            elementos[i + 1] = elementos[i];
        }
        elementos[posicao] = elemento;
        totalDeElementos++;
    }

    public T pega(int posicao) {
        if (!this.posicaoOcupada(posicao)) {
            throw new IllegalArgumentException("Posição inválida");
        }
        return (T) this.elementos[posicao];
    }

    private boolean posicaoOcupada(int posicao) {
        return posicao >= 0 && posicao < this.totalDeElementos;
    }

    public void remove(int posicao) {
        if (!posicaoOcupada(posicao)) {
            throw new IllegalArgumentException("Posição inválida");
        }

        for (int i = posicao; i < totalDeElementos - 1; i++) {
            elementos[i] = elementos[i + 1];
        }
        totalDeElementos--;
    }

    public boolean contem(T elemento) {
        for (int i = 0; i < this.totalDeElementos; i++) {
            if (elemento.equals(this.elementos[i])) {
                return true;
            }
        }
        return false;
    }

    public int tamanho() {
        return totalDeElementos;
    }

    public String toString() {
        if (this.totalDeElementos == 0) {
            return "[]";
        }
        StringBuilder builder = new StringBuilder();
        builder.append("[");
        for (int i = 0; i < this.totalDeElementos; i++) {
            builder.append(this.elementos[i]);
            if (i < this.totalDeElementos - 1) {
                builder.append(", ");
            }
        }
        builder.append("]");
        return builder.toString();
    }
}

