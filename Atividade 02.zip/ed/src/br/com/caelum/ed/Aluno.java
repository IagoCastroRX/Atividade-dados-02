package br.com.caelum.ed;

public class Aluno {
	private String nome;
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
        this.nome = nome;
    }
	
	public String toString() {
		return this.nome;
	}
	
	public boolean equals(Object o) {
		Aluno outro = (Aluno)o;
		return this.nome.equals(outro.nome);
	}
	
	//1) Adiciona um dado aluno no fim da lista
	public void adicionaFim(ListaAlunos lista) {
		lista.adiciona(this);
	}
	
	//2) Adiciona um dado aluno em uma dada posição
	public void adicionaPosicao(ListaAlunos lista, int posicao) {
        lista.adiciona(posicao, this);
    }
	
	//3)Pega o aluno de dada posição
	public Aluno pegaPosicao(ListaAlunos lista, int posicao) {
        return lista.pega(posicao);
    }
	
	//4) Remove o aluno de dada posição
	public void removePosicao(ListaAlunos lista, int posicao) {
        lista.remove(posicao);
    }
	
	//5) Verifica se um dado aluno está armazenado
    public boolean estaArmazenado(ListaAlunos lista) {
        return lista.contem(this);
    }

    //6) Informa o número de alunos armazenados
    public int numeroDeAlunosArmazenados(ListaAlunos lista) {
        return lista.tamanho();
    }
}
